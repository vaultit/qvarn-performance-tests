__version__ = "0.5+git"
__version_info__ = (0, 5, '+git')
