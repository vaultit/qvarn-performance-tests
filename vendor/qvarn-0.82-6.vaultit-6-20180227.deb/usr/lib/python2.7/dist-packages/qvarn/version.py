__version__ = "0.82-6.vaultit"
__version_info__ = (0, 82, '6.vaultit')
