# Copyright (C) 2017  Lars Wirzenius
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import jwt


JWT_SIGNING_ALGORITHM = 'RS512'


class TokenCache:

    def __init__(self):
        self._cache = {}

    def parse(self, token, key, audience):
        if token not in self._cache:
            if len(self._cache) > 1024:  # pragma: no cover
                self._cache = {}
            decoded = self._decode(token, key, audience)
            self._cache[token] = decoded
        return self._cache[token]

    def _decode(self, token, key, audience):
        return jwt.decode(
            token,
            key=key.exportKey('OpenSSH'),
            audience=None, options={'verify_aud': False})


_cache = TokenCache()


def create_token(claims, signing_key):
    return jwt.encode(
        claims,
        signing_key.exportKey('PEM'),
        algorithm=JWT_SIGNING_ALGORITHM)


def decode_token(token, key, audience):
    return _cache.parse(token, key, audience)
