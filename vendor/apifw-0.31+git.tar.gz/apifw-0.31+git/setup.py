# Copyright 2017 Lars Wirzenius

import importlib.machinery

from setuptools import setup

version = (
    importlib.machinery.
    SourceFileLoader('version', 'apifw/version.py').
    load_module()
)

setup(
    name='apifw',
    version=version.__version__,
    author='Lars Wirzenius',
    author_email='liw@liw.fi',
    url='http://liw.fi/apifw/',
    description='Python framework for RESTful JSON API backends',
    long_description='''\
This package contains the Python module apifw, which implements a small
framework for implemnting backends with a RESTful JSON HTTP API.
''',
    packages=['apifw'],
    install_requires=[
        'bottle',
        'cryptography',
        'gunicorn',
        'pycryptodome',
        'pyjwt',
    ],
)

